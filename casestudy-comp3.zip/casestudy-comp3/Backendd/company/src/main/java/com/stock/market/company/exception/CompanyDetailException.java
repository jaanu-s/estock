package com.stock.market.company.exception;

public class CompanyDetailException extends Exception {
	public CompanyDetailException(String message) {
		super(message);
	}
}
