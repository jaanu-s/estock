package com.stock.market.company.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.stock.market.company.entity.CompanyDetails;
import com.stock.market.company.entity.Price;

@Repository
public class CompanyDetailsRepository {

	 @Autowired
	 private DynamoDBMapper dynamoDBMapper;
	 
	 public CompanyDetails save(CompanyDetails companyDetails) {
	        dynamoDBMapper.save(companyDetails);
	        return companyDetails;
	  }
	 
	 public List<CompanyDetails> findAll(){
		 return dynamoDBMapper.scan(CompanyDetails.class, new DynamoDBScanExpression());
	 }
	 public CompanyDetails findByCompanyCode(String companyCode) {
		// System.out.println("dhe"+dynamoDBMapper.load(CompanyDetails.class, companyCode));
		 //return dynamoDBMapper.load(CompanyDetails.class, companyCode);
		 
		 Map<String, AttributeValue> eav = new HashMap<String, AttributeValue>();
	        eav.put(":val1", new AttributeValue().withS(companyCode));

	        DynamoDBScanExpression scanExpression = new DynamoDBScanExpression()
	            .withFilterExpression("companyCode = :val1 ").withExpressionAttributeValues(eav);

	        List<CompanyDetails> resultPrice = dynamoDBMapper.scan(CompanyDetails.class, scanExpression);
	        if(resultPrice.isEmpty()) {
	        	return null;
	        }
	        return resultPrice.get(0);
		 
	 }

	 public void deleteByCompanyCode(String companyCode) {
	     dynamoDBMapper.delete(findByCompanyCode(companyCode));
	    }
}
