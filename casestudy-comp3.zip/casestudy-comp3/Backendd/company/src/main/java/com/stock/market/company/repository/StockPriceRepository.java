package com.stock.market.company.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.stock.market.company.entity.CompanyDetails;
import com.stock.market.company.entity.Price;
import com.stock.market.company.entity.UserDetail;


@Repository
public class StockPriceRepository{
	@Autowired
	private DynamoDBMapper dynamoDBMapper;
	
	 public Price save(Price price) {
	        dynamoDBMapper.save(price);
	        return price;
	  }
	
	public List<Price> findByCompanyCodeOrderByCreationDateDesc(String companyCode) {
		//List<Price> price = findAllByOrderByCreationDateDesc();
		Map<String, AttributeValue> eav = new HashMap<String, AttributeValue>();
        eav.put(":val1", new AttributeValue().withS(companyCode));

        DynamoDBScanExpression scanExpression = new DynamoDBScanExpression()
            .withFilterExpression("companyCode = :val1 ").withExpressionAttributeValues(eav);

        List<Price> resultPrice = dynamoDBMapper.scan(Price.class, scanExpression);

        for (Price price : resultPrice) {
            System.out.println(price);
        }
		//if (!CollectionUtils.isEmpty(price)) {
		//	List<Price> priceDetails = price.stream()
		//			.filter(register -> companyCode.equals(register.getCompanyCode())).sorted().findAny();
		//	return priceDetails;
		//} else {
		//	return Optional.empty();
		//}
		return resultPrice;
	}
	
	 public List<Price> findAllByOrderByCreationDateDesc(){
		 return dynamoDBMapper.scan(Price.class, new DynamoDBScanExpression());
	 }

	 public void deleteAllByCompanyCode(String companyCode) {
		 List<Price> resultPrice = findByCompanyCodeOrderByCreationDateDesc(companyCode);
		 for (Price price : resultPrice) {
			 dynamoDBMapper.delete(price);
	        }
		 
		// CompanyDetails cmp = dynamoDBMapper.load(CompanyDetails.class, companyCode);
	     //   dynamoDBMapper.delete(cmp);
	    }
 
	
}
