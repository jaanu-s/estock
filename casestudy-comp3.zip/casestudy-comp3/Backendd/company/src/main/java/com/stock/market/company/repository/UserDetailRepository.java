package com.stock.market.company.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.stock.market.company.entity.CompanyDetails;
import com.stock.market.company.entity.UserDetail;


@Repository
public class UserDetailRepository {

	@Autowired
	private DynamoDBMapper dynamoDBMapper;

	public Optional<UserDetail> findByusername(String email) {
		List<UserDetail> registers = findAll();
		if (!CollectionUtils.isEmpty(registers)) {
			Optional<UserDetail> registerDetails = registers.stream()
					.filter(register -> email.equals(register.getUsername())).findAny();
			return registerDetails;
		} else {
			return Optional.empty();
		}
	}
	
	public List<UserDetail> findAll(){
		 return dynamoDBMapper.scan(UserDetail.class, new DynamoDBScanExpression());
	 }
}
