package com.stock.market.stockprice.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PriceDto {

	private double stckPrice;
}
