package com.stock.market.stockprice.repository;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
//import com.stock.market.company.entity.CompanyDetails;
import com.stock.market.stockprice.entity.Price;

@Repository
public class StockPriceRepository {
	
	@Autowired
	private DynamoDBMapper dynamoDBMapper;
	
	public Price save(Price price) {
		dynamoDBMapper.save(price);
		return price;
	  }

}
