package com.stock.market.stockprice.service.impl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.OptionalDouble;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.stock.market.stockprice.dto.PriceDto;
import com.stock.market.stockprice.dto.ViewStockPriceDetailsDto;
import com.stock.market.stockprice.entity.Price;
import com.stock.market.stockprice.repository.StockPriceRepository;
import com.stock.market.stockprice.service.IStockPriceService;

import lombok.extern.log4j.Log4j2;


@Service
@Log4j2
public class StockPriceServiceImpl implements IStockPriceService {
	
	 @Autowired
	 private DynamoDBMapper dynamoDBMapper;
	 
	@Autowired
	private StockPriceRepository stockPriceRepository;


	@Transactional
	public void addStockPrice(PriceDto priceDto, String companyCode) throws ParseException {
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		String creationDateString = df.format(new Date());
		Date requiredDate = df.parse(creationDateString);
		System.out.println("price"+priceDto.getStckPrice());
		Price price = Price.builder().stckPrice(priceDto.getStckPrice()).companyCode(companyCode)
				.creationDate(new Date()).build();
		log.info("StockPriceServiceImpl.addStockPrice, Price - {} ", price);
		stockPriceRepository.save(price);

	}

	@Override
	@Transactional
	public ViewStockPriceDetailsDto viewStockDetails(String companyCode, Date startDate, Date endDate)
			throws ParseException {
		// TODO Auto-generated method stub
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

		//String startDateString = df.format(startDate);
		//String endDateString = df.format(endDate);
		//Date startDateRequired = df.parse(startDateString);
		//Date endDateRequired = df.parse(endDateString);
		Map<String, AttributeValue> eav = new HashMap<String, AttributeValue>();
        eav.put(":val1", new AttributeValue().withS(companyCode));

        DynamoDBScanExpression scanExpression = new DynamoDBScanExpression()
            .withFilterExpression("companyCode = :val1 ").withExpressionAttributeValues(eav);

        List<Price> resultPrice = dynamoDBMapper.scan(Price.class, scanExpression);
        System.out.println("resultPrice"+ resultPrice.get(0));
		log.debug("StockPriceServiceImpl.viewStockDetails, priceList - {}", resultPrice);
		List<Double> stockPriceList = new ArrayList<Double>();
		List<Price> finalResult = resultPrice.stream().filter(x -> x.getCreationDate().getTime()> startDate.getTime() && x.getCreationDate().getTime()< endDate.getTime()).
		collect(Collectors.toList());
		if (!finalResult.isEmpty()) {
			for (Price price : finalResult) {
				if (!ObjectUtils.isEmpty(price.getStckPrice())) {
					stockPriceList.add(price.getStckPrice());

				}
			}
		}
		Collections.sort(stockPriceList);
		ViewStockPriceDetailsDto viewStockPriceDetailsDto = null;
		if (!ObjectUtils.isEmpty(stockPriceList)) {
			double min = stockPriceList.get(0);
			double max = stockPriceList.get(stockPriceList.size() - 1);
			OptionalDouble average = stockPriceList.stream().mapToDouble(n -> n).average();
			viewStockPriceDetailsDto = ViewStockPriceDetailsDto.builder().average(average).min(min).max(max)
					.stockPriceList(stockPriceList).build();
		}
		log.info("StockPriceServiceImpl.viewStockDetails, final response - {}", viewStockPriceDetailsDto);
		return viewStockPriceDetailsDto;
	}
}
